@extends('layouts.layoutadmin')

@section ('paginaCorrente', 'Cadastro')

@section('breadcrumb')
        <li class="breadcrumb-item"><a href="/">Início</a></li>
        <li class="breadcrumb-item active">Cadastro</li>
@endsection

@section('conteudo')

@endsection