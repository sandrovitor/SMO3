<?php
namespace App;

echo 'Carregou teste';

class Teste
{
    
}